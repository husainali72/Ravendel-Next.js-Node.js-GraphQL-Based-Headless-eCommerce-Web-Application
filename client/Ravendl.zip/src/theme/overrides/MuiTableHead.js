import { colors } from '@mui/material';

export default {
  styleOverrides: {
  root: {
    backgroundColor: colors.grey[50]
  }}
};
