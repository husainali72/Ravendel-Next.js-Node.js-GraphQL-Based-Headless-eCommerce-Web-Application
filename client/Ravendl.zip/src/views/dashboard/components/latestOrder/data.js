export default [
    {
      id: 1,
      ref: 'CDD1049',
      amount: 30.5,
      customer: {
        name: 'Ekaterina Tankova'
      },
      createdAt: 1555016400000,
      status: 'pending'
    },
    {
      id: 2,
      ref: 'CDD1048',
      amount: 25.1,
      customer: {
        name: 'John Doe'
      },
      createdAt: 1555016400000,
      status: 'pending'
    }
];
  