import AllFAQ from "./allFaq";
import AddFAQ from "./addFaq";
import EditFAQ from "./editFaq";

export { AddFAQ, AllFAQ, EditFAQ };