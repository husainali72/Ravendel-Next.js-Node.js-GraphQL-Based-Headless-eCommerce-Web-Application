import AllOrders from "./allOrders";
import ViewOrder from "./viewOrder";

export { AllOrders, ViewOrder };