import AllPages from "./allPage";
import AddPage from "./addPage";
import EditPage from "./editPage";

export { AllPages, AddPage, EditPage };