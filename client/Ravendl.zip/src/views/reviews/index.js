import EditReview from "./editreview";
import AllReviews from "./allreviews";

export { AllReviews, EditReview };
