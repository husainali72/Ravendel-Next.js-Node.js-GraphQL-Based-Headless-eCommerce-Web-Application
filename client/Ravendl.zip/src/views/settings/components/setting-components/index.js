import SettingBlock from './setting-blocks';
import SettingTextInput from './setting-textinput';
import SettingSelectComponent from './setting-selectInput';

export {
    SettingTextInput,
    SettingBlock,
    SettingSelectComponent
}